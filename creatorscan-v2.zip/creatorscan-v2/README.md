# 📡 CreatorScan — YouTube Creator Discovery Tool
### Built for Creators Dream · Internal Tool

Search 1,000+ YouTube creators by niche, tier, and region in one click.

---

## 🚀 Deploy in 5 Minutes

### Step 1 — Install Vercel CLI (one time only)
```
npm install -g vercel
```

### Step 2 — Open the project folder
Extract this ZIP, then open your terminal/command prompt inside the folder:
```
cd creatorscan-deploy
```

### Step 3 — Login to Vercel (one time only)
```
vercel login
```
Opens your browser → log in with GitHub/Google/email.

### Step 4 — First deploy
```
vercel
```
When it asks questions:
- Set up and deploy? → **Y**
- Which scope? → pick your account
- Link to existing project? → **N**
- Project name? → **creatorscan** (or anything)
- In which directory? → just press **Enter** (it's the current folder)

### Step 5 — Add your API keys
Run these two commands one at a time:
```
vercel env add YOUTUBE_API_KEY
```
Paste your YouTube API key when prompted, select **Production + Preview + Development**, press Enter.

```
vercel env add ANTHROPIC_API_KEY
```
Paste your Anthropic API key when prompted, select **Production + Preview + Development**, press Enter.

### Step 6 — Deploy to production
```
vercel --prod
```
Done. Your live URL will be printed in the terminal. ✅

---

## 🔑 Getting Your API Keys

### YouTube Data API v3 (Free)
1. Go to https://console.cloud.google.com
2. Create a new project (or use existing)
3. Go to **APIs & Services → Library**
4. Search **YouTube Data API v3** → Enable it
5. Go to **APIs & Services → Credentials**
6. Click **Create Credentials → API Key**
7. Copy the key — that's your `YOUTUBE_API_KEY`

> Free quota: 10,000 units/day (~100 searches/day)

### Anthropic API Key
1. Go to https://console.anthropic.com
2. Go to **API Keys → Create Key**
3. Copy the key — that's your `ANTHROPIC_API_KEY`

> Cost: ~₹0.05–0.10 per search (Claude Haiku)

---

## 🔄 Updating After Changes

Whenever you update any file, just run:
```
vercel --prod
```

---

## 📁 File Structure
```
creatorscan-deploy/
├── index.html          ← Frontend (hero, search panel, results)
├── api/
│   └── search.js       ← Backend (YouTube API + AI enrichment)
├── package.json        ← Node 24.x config
├── vercel.json         ← Routing + 60s timeout
├── .env.example        ← API key template
└── README.md           ← This file
```

---

## ⚙️ How It Works

| Step | What happens |
|---|---|
| You search | Frontend sends keyword + niche + tier + region to `/api/search` |
| Wave 1 | 30 queries fired in parallel → YouTube Data API → up to 1,500 channel IDs |
| Wave 2 | Page 2 of all queries → +1,200 more IDs |
| Wave 3 | Page 3 of top 15 queries → +600 more IDs |
| Region filter | Strict: country code first, then script detection, then keyword signals |
| AI enrich | Claude Haiku tags niche, region label, content type, relevance score |
| Return | Sorted by relevance, all results sent to frontend |

---

## 🆘 Troubleshooting

| Error | Fix |
|---|---|
| "Missing YOUTUBE_API_KEY" | Run `vercel env add YOUTUBE_API_KEY` then `vercel --prod` |
| "Missing ANTHROPIC_API_KEY" | Run `vercel env add ANTHROPIC_API_KEY` then `vercel --prod` |
| "Quota exceeded" | YouTube free quota used up — wait 24h or create a new API key |
| "Invalid API key" | Re-check the key in Vercel Dashboard → Settings → Environment Variables |
| 0 results | Try a different keyword or switch region to Global first to test |
| Search times out | Normal for large searches — Vercel has 60s limit, try a specific niche |

---

Built with ❤️ for Creators Dream · Powered by YouTube Data API v3 + Claude AI
