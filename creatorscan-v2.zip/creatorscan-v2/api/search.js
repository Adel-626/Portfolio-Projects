const https = require('https');

const YT_KEY = process.env.YOUTUBE_API_KEY;
const AN_KEY = process.env.ANTHROPIC_API_KEY;

// ── Helpers ───────────────────────────────────────────────────────────────────

function getTier(subs) {
  if (subs >= 5_000_000) return { label:'Mega',  color:'#f87171' };
  if (subs >= 1_000_000) return { label:'Macro', color:'#fbbf24' };
  if (subs >=   100_000) return { label:'Mid',   color:'#34d399' };
  if (subs >=    10_000) return { label:'Micro', color:'#60a5fa' };
  return                        { label:'Nano',  color:'#a78bfa' };
}
function fmt(n) {
  const num = parseInt(n) || 0;
  if (num >= 1_000_000) return (num/1_000_000).toFixed(1)+'M';
  if (num >=     1_000) return (num/1_000).toFixed(1)+'K';
  return String(num);
}
function extractEmail(text) {
  if (!text) return null;
  const m = text.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/);
  return m ? m[0] : null;
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Region config ─────────────────────────────────────────────────────────────

const REGION_CONFIG = {
  'india':          { cc:'IN', countries:['IN'] },
  'south-asia':     { cc:'IN', countries:['IN','PK','BD','LK','NP'] },
  'north-america':  { cc:'US', countries:['US','CA'] },
  'europe':         { cc:'GB', countries:['GB','DE','FR','IT','ES','NL','SE','PL','RU','UA','NO','FI','DK','PT','AT','BE','CH','CZ','HU','RO'] },
  'southeast-asia': { cc:'SG', countries:['SG','TH','ID','MY','PH','VN','MM','KH','LA','BN'] },
  'middle-east':    { cc:'AE', countries:['AE','SA','EG','KW','QA','OM','BH','JO','LB','IQ','IR','TR','IL','YE'] },
  'global':         { cc:null, countries:null },
};

// ── 30 niche query templates ──────────────────────────────────────────────────
// Each niche has 30 distinct queries to maximise unique channel discovery

const NICHE_QUERIES = {
  'ai':['AI tools review','artificial intelligence tutorial','ChatGPT how to','machine learning explained','AI automation workflow','generative AI art','AI productivity hacks','AI software comparison','deep learning course','AI apps 2024','AI for small business','prompt engineering guide','AI video generation','Midjourney tutorial','AI writing assistant','GitHub Copilot tutorial','AI news update','n8n automation','Claude AI tutorial','Gemini AI review','Sora AI video','AI image tools','AI voice cloning','LLM tutorial','local AI models','AI agent automation','no-code AI tools','AI content creation','AI marketing tools','future of AI'],
  'tech':['tech gadgets review','smartphone comparison 2024','best laptop review','tech unboxing video','tech news today','mobile phone test','tech life hacks','consumer electronics review','best software 2024','must-have apps','mini PC review','gaming PC build','monitor review','mechanical keyboard review','best earbuds review','smartwatch review 2024','router review','tech setup tour','budget tech','premium tech review','tech myths busted','software tutorial','app comparison','tech for beginners','tech channel India','Chinese tech review','tech deals','tech buying guide','open source software','developer tools review'],
  'product':['product review channel','unboxing best products','honest product review','must-have gadgets','product comparison video','consumer product test','product haul video','buying guide 2024','value for money products','budget vs premium','product fails compilation','top 10 products','online shopping review','Amazon product review','product recommendations','product testing lab','cheap finds review','surprise product review','product upgrade guide','product wishlist','favourite products','everyday carry review','home product review','kitchen product review','fitness product review','travel product review','tech product review','beauty product review','sustainable products','subscription box review'],
  'educational':['education explained','science facts channel','history documentary','learning new skills','study with me','educational animation','how things work','explainer video channel','knowledge channel','general knowledge quiz','exam preparation tips','UPSC preparation','NEET preparation','JEE preparation','competitive exam channel','school curriculum explained','college study tips','language learning','mathematics tutorial','physics explained','chemistry basics','biology explained','geography facts','civics explained','economics basics','psychology facts','philosophy explained','coding for beginners','financial literacy basics','life skills education'],
  'career':['career advice channel','job interview tips','resume writing guide','salary negotiation tips','LinkedIn profile tips','career change guide','work from home tips','freelancing for beginners','side hustle ideas','government job preparation','banking exam preparation','GATE preparation','MBA tips','placement preparation','job search strategy','corporate survival guide','professional networking','workplace tips','HR interview questions','internship guide','career growth roadmap','remote work tips','digital nomad career','portfolio building','upskilling guide','job market trends','startup career','tech career guide','finance career guide','marketing career tips'],
  'infotainment':['amazing facts Hindi','interesting facts world','did you know facts','general knowledge entertainment','mystery facts channel','true crime India','documentary style facts','top 10 list channel','strange facts science','history mysteries','unsolved cases','world records channel','bizarre facts channel','mind-blowing science','unexplained phenomena','urban legends facts','ancient civilization facts','space facts channel','ocean facts channel','animal facts channel','human body facts','technology facts','food facts channel','country facts travel','language facts','money facts wealth','sports records facts','celebrity unknown facts','viral facts explained','psychology tricks facts'],
  'tips-tricks':['life hacks channel','top productivity tips','phone tips and tricks','Windows tips 2024','Mac tips tricks','Android tips hidden','iPhone hidden features','social media tips','Google tips tricks','Excel tips tricks','keyboard shortcuts','time management tips','organisation tips','minimalist tips','morning routine tips','night routine tips','study tips exam','money saving hacks','cooking hacks','cleaning hacks','travel hacks tips','fitness hacks','mental health tips','relationship tips','parenting tips hacks','fashion tips affordable','home decor hacks','car maintenance tips','photography tips phone','content creation tips'],
  'finance':['stock market basics','mutual fund investment','personal finance tips','financial freedom guide','investing for beginners','trading strategies','SIP investment plan','tax saving guide 2024','crypto explained','real estate investment','passive income ideas','dividend investing','index fund guide','budgeting for beginners','debt-free journey','emergency fund tips','insurance basics','EPF PPF explained','financial planning guide','wealth building habits','retirement planning','income tax filing','GST explained','business finance','forex trading basics','US stock market India','startup funding explained','IPO investing guide','commodity trading','options trading basics'],
  'fashion':['fashion lookbook','outfit of the day','fashion haul video','style guide men','style guide women','affordable fashion finds','ethnic wear styling','western wear India','fashion trends 2024','celebrity fashion inspired','capsule wardrobe','thrift flip fashion','budget fashion haul','sustainable fashion','streetwear fashion','Korean fashion India','wedding outfit ideas','office wear tips','casual outfit ideas','accessories styling','bags and shoes haul','colour coordination tips','body type fashion','plus size fashion','denim styling tips','seasonal fashion guide','fashion designer interview','fashion week recap','mens grooming tips','womens styling tips'],
  'beauty':['skincare routine Hindi','makeup tutorial beginner','skincare products India','beauty tips natural','glow skin secrets','cosmetics review India','drugstore makeup review','hair care routine','nail art tutorial','beauty transformation','Korean skincare routine','Ayurvedic skin tips','anti-aging skincare','acne treatment tips','sunscreen guide India','vitamin C serum review','moisturiser comparison','face wash review','hair oil review','hair mask tutorial','eyebrow tutorial','foundation routine','lip care tips','under eye care','body care routine','men skincare routine','skincare for beginners','budget beauty haul','expensive vs cheap skincare','beauty myths busted'],
  'fitness':['home workout no equipment','gym beginner guide','yoga for beginners','weight loss journey','muscle building plan','HIIT workout routine','calisthenics workout','running tips beginners','diet plan weight loss','protein intake guide','pre-workout post-workout','bodyweight training','flexibility exercises','sports performance','mental health exercise','intermittent fasting guide','keto diet explained','nutrition basics','supplement guide India','fitness myths busted','fitness transformation','workout motivation','best exercise equipment','CrossFit beginners','swimming tips','cycling fitness','martial arts beginners','Zumba workout','pilates beginners','senior fitness tips'],
  'food':['easy recipe at home','street food India tour','home cooking channel','food vlog travel','quick dinner recipes','chef cooking tutorial','food review restaurant','baking from scratch','traditional recipes','healthy meal prep','budget cooking ideas','one pot recipes','air fryer recipes','pressure cooker recipes','5 ingredient recipes','vegetarian recipes','vegan recipes India','regional Indian recipes','fusion food recipe','dessert recipes easy','breakfast ideas quick','snack recipes','party food ideas','food challenge video','mukbang eating show','restaurant review India','food market tour','fermented food recipes','pizza homemade','pasta homemade'],
  'travel':['travel vlog India','budget travel tips','travel guide hidden gems','solo travel experience','road trip vlog','luxury travel review','backpacking adventure','visa guide travel','flight booking tips','hotel review budget','tourist places India','hill stations India','beach destinations India','foreign country vlog','Europe travel guide','Southeast Asia travel','travel packing tips','travel photography tips','travel itinerary 7 days','weekend getaway ideas','adventure travel','camping guide','trekking India','cruise travel review','train travel India','motorcycle trip India','travel food guide','travel safety tips','eco tourism travel','digital nomad travel'],
  'gaming':['gaming gameplay Hindi','mobile gaming tips','best games 2024','PC gaming India','gaming setup tour','esports highlights','game review honest','FPS gaming tactics','BGMI tips tricks','Free Fire pro tips','Minecraft builds','GTA 5 gameplay','Valorant guide','Call of Duty tips','FIFA gameplay','sports games India','indie games review','retro gaming channel','gaming news India','game ranking tier list','gaming accessories review','budget gaming PC','console gaming India','PS5 gameplay','Xbox gameplay','Nintendo Switch','gaming tournament highlights','streaming tips gaming','game glitches funny','gaming challenge video'],
  'business':['business idea India','startup success story','entrepreneur journey','digital marketing tips','social media marketing','content creator income','affiliate marketing guide','dropshipping India','ecommerce tips India','Amazon FBA India','small business tips','side income ideas India','passive income online','freelancing income','YouTube monetization','Instagram monetization','personal branding tips','business case study','marketing strategy','sales skills tips','pitch deck guide','business plan writing','venture capital explained','angel investor tips','franchise business India','import export business','service business tips','SaaS business model','B2B marketing','brand building social media'],
  'news':['current affairs India','news analysis channel','independent journalism','political commentary','economy news India','daily news briefing','world news explained','tech news India','sports news highlights','entertainment news','investigative reporting','news debate channel','fact check viral news','breaking news analysis','election news India','India foreign policy','geopolitical analysis','budget news analysis','state politics news','court verdict explained','environment news','social issues India','human interest story','startup news India','business news daily','health news India','education news','crime news India','disaster news report','interview political leader'],
};

// ── 30 region-specific search suffixes ───────────────────────────────────────

const REGION_KWS = {
  'india': [
    'India Hindi','Indian creator','Bharat YouTube','Hindi channel','Hinglish creator',
    'India trending','Desi YouTube','India 2024','Mumbai YouTube','Delhi creator',
    'Bangalore channel','Chennai creator','Kolkata YouTube','Hyderabad creator','Pune YouTube',
    'हिंदी चैनल','भारत','India viral','top Indian YouTuber','India subscribers',
    'Hindi speaking','Indian audience','made in India','India content','desi content',
    'Indian English','India vlog','India review','India tutorial','India guide',
  ],
  'south-asia': [
    'India Hindi','Pakistan Urdu','Bangladesh Bengali','Sri Lanka Sinhala','Nepal Nepali',
    'South Asia','Desi content','Punjabi channel','Marathi YouTube','Tamil YouTube',
    'Telugu creator','Kannada channel','Malayalam creator','Gujarati YouTube','Odia channel',
    'Sindhi creator','South Asian creator','Subcontinent YouTube','SAARC countries','Asian content',
    'India Pakistan','Bangladesh creator','Nepali vlog','Sri Lankan YouTube','Pakistani creator',
    'Urdu channel','Bengali content','South Asian audience','Desi YouTube','regional language India',
  ],
  'north-america': [
    'USA American','US YouTube','Canada creator','American vlogger','North America channel',
    'US trending','New York vlog','California creator','Toronto YouTube','American lifestyle',
    'US review channel','American tech','English speaking US','US daily life','American culture',
    'Canadian creator','US college life','American foodie','US travel','American commentary',
    'US startup','Silicon Valley','American finance','US fitness','American comedy',
    'US politics','American news','US gaming','American beauty','US fashion',
  ],
  'europe': [
    'UK British YouTube','Germany German creator','France French channel','Europe travel','European creator',
    'London vlog','Berlin YouTube','Paris channel','British accent','English UK creator',
    'Italian YouTube','Spanish creator','Dutch channel','Swedish YouTube','Polish creator',
    'European lifestyle','UK commentary','British comedy','German tech','French beauty',
    'UK gaming','European travel','British food','German engineering','Scandinavian lifestyle',
    'UK education','European news','British vlog','EU creator','Nordic creator',
  ],
  'southeast-asia': [
    'Indonesia YouTube','Philippines creator','Thailand vlog','Malaysia channel','Singapore YouTube',
    'Vietnam creator','Southeast Asia travel','Indonesian language','Filipino English','Thai YouTube',
    'Malay content','Tagalog channel','SEA creator','Jakarta vlog','Bangkok YouTube',
    'Manila creator','Kuala Lumpur channel','Singapore content','Vietnamese creator','Myanmar YouTube',
    'SEA lifestyle','Southeast Asian food','SEA travel','tropical lifestyle','ASEAN creator',
    'Bahasa Indonesia','Tagalog YouTube','Khmer channel','Lao creator','Brunei YouTube',
  ],
  'middle-east': [
    'Arabic YouTube','Saudi Arabia creator','UAE Dubai channel','Arab vlogger','Middle East content',
    'Egyptian YouTube','Gulf creator','Arabic language channel','Dubai lifestyle','Riyadh creator',
    'Cairo YouTube','Kuwait channel','Qatar creator','Jordan YouTube','Lebanon channel',
    'Arabic speaking','Arab audience','Islamic content','Halal lifestyle','Middle Eastern food',
    'Arabic tech channel','Gulf lifestyle','Arab comedy','Arabic education','Saudi creator',
    'UAE Arabic','Egyptian creator','Arab gaming','Arabic beauty','Gulf travel',
  ],
  'global': [
    '','top YouTube','English creator','viral channel','trending YouTube',
    'popular channel','best creator','global audience','international channel','world YouTube',
    'English speaking','top influencer','famous YouTuber','worldwide creator','global content',
    'viral content','trending video','popular YouTube','English channel','international creator',
    'top 100 YouTube','most subscribed','viral YouTube','best channel 2024','trending 2024',
    'viral 2024','popular creator','world trending','global trending','English YouTube',
  ],
};

// ── HTTP ──────────────────────────────────────────────────────────────────────

function httpGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(new Error('JSON parse: ' + data.substring(0,200))); }
      });
    });
    req.on('error', reject);
    req.setTimeout(12000, () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

function httpPost(hostname, path, body, headers) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = https.request({
      hostname, path, method:'POST',
      headers:{ 'Content-Type':'application/json','Content-Length':Buffer.byteLength(payload), ...headers }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(new Error('JSON parse error')); }
      });
    });
    req.on('error', reject);
    req.setTimeout(25000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.write(payload);
    req.end();
  });
}

// ── YouTube search ────────────────────────────────────────────────────────────

async function ytSearch(query, regionCode, pageToken) {
  try {
    let url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&maxResults=50&q=${encodeURIComponent(query)}&key=${YT_KEY}&order=relevance`;
    if (regionCode) url += `&regionCode=${regionCode}`;
    if (pageToken)  url += `&pageToken=${encodeURIComponent(pageToken)}`;
    const data = await httpGet(url);
    if (data.error) {
      return { items:[], nextPageToken:null, ytError:data.error };
    }
    return data;
  } catch(e) {
    return { items:[], nextPageToken:null };
  }
}

async function fetchChannelDetails(ids) {
  const results = [];
  // Fetch all batches in parallel for speed
  const batches = [];
  for (let i = 0; i < ids.length; i += 50) batches.push(ids.slice(i, i+50));
  const responses = await Promise.allSettled(batches.map(batch => {
    const url = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&id=${batch.join(',')}&key=${YT_KEY}`;
    return httpGet(url);
  }));
  for (const r of responses) {
    if (r.status === 'fulfilled' && !r.value.error && r.value.items) {
      results.push(...r.value.items);
    }
  }
  return results;
}

// ── Region filter — strict but with fallback ──────────────────────────────────

const INDIA_WORDS = /\b(hindi|india|indian|bharat|hinglish|desi|mumbai|delhi|bengaluru|bangalore|hyderabad|chennai|kolkata|pune|jaipur|surat|ahmedabad|lucknow|₹|crore|lakh|rupee|bhai|yaar|abhi|aur|nahi|kya|hai)\b/i;
const INDIA_SCRIPT = /[\u0900-\u097F\u0A00-\u0A7F\u0B00-\u0B7F\u0C00-\u0C7F\u0D00-\u0D7F]/;

const MIDEAST_WORDS = /\b(arabic|arab|dubai|abu dhabi|saudi|riyadh|jeddah|kuwait|qatar|doha|oman|muscat|bahrain|jordan|amman|egypt|cairo|lebanese|beirut|iraq|baghdad|gulf|halal|allah|ramadan)\b/i;
const MIDEAST_SCRIPT = /[\u0600-\u06FF\u0750-\u077F]/;

const SEA_WORDS = /\b(indonesia|indonesian|philippines|filipino|thailand|thai|malaysia|malay|singapore|vietnam|vietnamese|myanmar|burmese|cambodia|khmer|laos|lao|brunei|jakarta|manila|bangkok|kuala lumpur|ho chi minh|yangon|phnom penh|vientiane)\b/i;
const SEA_SCRIPT = /[\u0E00-\u0E7F\u1000-\u109F\u1780-\u17FF\uAA60-\uAA7F]/;

function passesRegion(ch, region, conf) {
  if (region === 'global') return true;
  const cc = (ch.country || '').toUpperCase();
  // Hard match on country code — most reliable
  if (cc && conf.countries && conf.countries.includes(cc)) return true;
  // Soft fallback: text signals in description + name
  const text = ((ch.description || '') + ' ' + (ch.name || '') + ' ' + (ch.handle || '')).toLowerCase();
  if (region === 'india')          return INDIA_SCRIPT.test(text) || INDIA_WORDS.test(text);
  if (region === 'middle-east')    return MIDEAST_SCRIPT.test(text) || MIDEAST_WORDS.test(text);
  if (region === 'southeast-asia') return SEA_SCRIPT.test(text) || SEA_WORDS.test(text);
  // For other regions — if no country code was available, be permissive
  return false;
}

// ── AI enrich — batch 50 at a time ───────────────────────────────────────────

async function enrichBatch(batch, query, niche, region) {
  try {
    const summaries = batch.map((c, i) =>
      `${i}: name="${c.name.substring(0,40)}", subs=${c.subscribers}, country=${c.country||'?'}, desc="${c.description.substring(0,80)}"`
    ).join('\n');
    const prompt = `You are tagging YouTube creators. Search context: query="${query||niche}", region="${region}".
${summaries}
Return ONLY a valid JSON array with exactly ${batch.length} objects. No markdown, no explanation:
[{"nicheTag":"2-3 word tag","regionLabel":"city or country name","contentType":"Tutorial|Vlog|Review|News|Entertainment|Education|Shorts|Mixed","relevanceScore":50-100}]`;
    const r = await httpPost('api.anthropic.com', '/v1/messages', {
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 4000,
      messages: [{ role:'user', content:prompt }],
    }, { 'x-api-key': AN_KEY, 'anthropic-version': '2023-06-01' });
    const raw = (r.content?.[0]?.text || '[]').replace(/```json|```/g,'').trim();
    const tags = JSON.parse(raw);
    tags.forEach((t, i) => {
      if (!batch[i]) return;
      batch[i].nicheTag       = t.nicheTag    || null;
      batch[i].regionLabel    = t.regionLabel || null;
      batch[i].contentType    = t.contentType || null;
      batch[i].relevanceScore = parseInt(t.relevanceScore) || 70;
    });
  } catch(e) {
    console.error('AI enrich error:', e.message);
  }
}

// ── Main handler ──────────────────────────────────────────────────────────────

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST')   return res.status(405).json({ error:'Method not allowed' });

  if (!YT_KEY) return res.status(500).json({ error:'Missing YOUTUBE_API_KEY — add in Vercel → Settings → Environment Variables, then redeploy.' });
  if (!AN_KEY) return res.status(500).json({ error:'Missing ANTHROPIC_API_KEY — add in Vercel → Settings → Environment Variables, then redeploy.' });

  const { query='', niche='', tier='all', region='india' } = req.body || {};
  if (!query && !niche) return res.status(400).json({ error:'Please enter a keyword or select a niche.' });

  try {
    const regionConf = REGION_CONFIG[region] || REGION_CONFIG['global'];
    const regionCode = regionConf.cc;
    const regionKws  = REGION_KWS[region] || REGION_KWS['global'];

    // ── Build 30 query variations ──────────────────────────────────────────
    let queryList = [];
    if (niche && NICHE_QUERIES[niche]) {
      // Combine niche base queries with region keywords for max discovery
      queryList = NICHE_QUERIES[niche].map((base, i) => {
        const rk = regionKws[i] || '';
        return rk ? `${base} ${rk}` : base;
      });
    } else {
      // Free keyword — combine with all region keywords
      queryList = regionKws.map(rk => rk ? `${query} ${rk}` : query);
    }
    // Pad/trim to exactly 30
    while (queryList.length < 30) queryList.push(queryList[queryList.length - 1]);
    queryList = queryList.slice(0, 30);

    const seenIds    = new Set();
    const channelIds = [];

    function collect(items) {
      for (const item of (items || [])) {
        const id = item.snippet?.channelId || item.id?.channelId;
        if (id && !seenIds.has(id)) { seenIds.add(id); channelIds.push(id); }
      }
    }

    // ── Wave 1: all 30 queries in parallel (page 1) ────────────────────────
    console.log(`Wave 1: ${queryList.length} queries, region=${region}`);
    const w1 = await Promise.allSettled(queryList.map(q => ytSearch(q, regionCode)));
    const w1r = w1.map(r => r.status === 'fulfilled' ? r.value : { items:[], nextPageToken:null });

    // Check for API errors
    const firstErr = w1r.find(r => r.ytError);
    if (firstErr) {
      const e = firstErr.ytError;
      const m = e.message || JSON.stringify(e);
      if (m.includes('quota'))      return res.status(429).json({ error:'YouTube API quota exceeded. Wait 24h or add a second API key.' });
      if (m.includes('keyInvalid')) return res.status(401).json({ error:'Invalid YouTube API key. Check YOUTUBE_API_KEY in Vercel env vars.' });
      return res.status(500).json({ error:'YouTube API error: ' + m });
    }

    for (const r of w1r) collect(r.items);
    console.log(`After Wave 1: ${channelIds.length} unique IDs`);

    // ── Wave 2: page 2 of all queries that have a next page ───────────────
    const w2tasks = w1r
      .map((r, i) => ({ r, q: queryList[i] }))
      .filter(x => x.r.nextPageToken);
    if (w2tasks.length) {
      const w2 = await Promise.allSettled(w2tasks.map(x => ytSearch(x.q, regionCode, x.r.nextPageToken)));
      const w2r = w2.map(r => r.status === 'fulfilled' ? r.value : { items:[], nextPageToken:null });
      for (const r of w2r) collect(r.items);
      console.log(`After Wave 2: ${channelIds.length} unique IDs`);

      // ── Wave 3: page 3 of top 15 queries ──────────────────────────────
      const w3tasks = w2r
        .map((r, i) => ({ r, q: w2tasks[i]?.q }))
        .filter(x => x.r.nextPageToken && x.q)
        .slice(0, 15);
      if (w3tasks.length) {
        const w3 = await Promise.allSettled(w3tasks.map(x => ytSearch(x.q, regionCode, x.r.nextPageToken)));
        for (const r of w3) {
          if (r.status === 'fulfilled') collect(r.value.items);
        }
        console.log(`After Wave 3: ${channelIds.length} unique IDs`);
      }
    }

    if (!channelIds.length) {
      return res.status(200).json({ creators:[], total:0, message:'No channels found. Try a different keyword or switch regions.' });
    }

    // ── Fetch full channel details (parallel batches of 50) ───────────────
    console.log(`Fetching details for ${channelIds.length} channels...`);
    const rawChannels = await fetchChannelDetails(channelIds);
    console.log(`Got details for ${rawChannels.length} channels`);

    if (!rawChannels.length) {
      return res.status(200).json({ creators:[], total:0, message:'YouTube returned IDs but no details. Temporary API issue — try again.' });
    }

    // ── Format channels ───────────────────────────────────────────────────
    const channelMap = new Map();
    for (const ch of rawChannels) {
      if (channelMap.has(ch.id)) continue;
      const snip  = ch.snippet || {};
      const stats = ch.statistics || {};
      const brand = ch.brandingSettings?.channel || {};
      const subsRaw = parseInt(stats.subscriberCount) || 0;
      channelMap.set(ch.id, {
        id:          ch.id,
        name:        snip.title || 'Unknown',
        handle:      snip.customUrl ? '@' + snip.customUrl.replace(/^@/, '') : `@${ch.id}`,
        description: (snip.description || '').substring(0, 300),
        thumbnail:   snip.thumbnails?.high?.url || snip.thumbnails?.medium?.url || snip.thumbnails?.default?.url || null,
        country:     snip.country || null,
        subsRaw,
        subscribers: stats.hiddenSubscriberCount ? 'Hidden' : fmt(subsRaw),
        totalViews:  fmt(stats.viewCount),
        videoCount:  fmt(stats.videoCount),
        email:       extractEmail(snip.description) || extractEmail(brand.description) || null,
        profileUrl:  snip.customUrl
          ? `https://youtube.com/@${snip.customUrl.replace(/^@/, '')}`
          : `https://youtube.com/channel/${ch.id}`,
        tier:        getTier(subsRaw),
        nicheTag:    null, regionLabel:null, contentType:null, relevanceScore:70,
      });
    }

    let channels = Array.from(channelMap.values());

    // ── Strict region filter ───────────────────────────────────────────────
    if (region !== 'global') {
      const before = channels.length;
      channels = channels.filter(c => passesRegion(c, region, regionConf));
      console.log(`Region filter (${region}): ${before} → ${channels.length}`);
    }

    // ── Tier filter ───────────────────────────────────────────────────────
    if (tier !== 'all') {
      channels = channels.filter(c => c.tier?.label?.toLowerCase() === tier);
    }

    // ── AI enrich — ALL channels in parallel batches ──────────────────────
    if (AN_KEY && channels.length) {
      const batches = [];
      for (let i = 0; i < channels.length; i += 50) batches.push(channels.slice(i, i + 50));
      console.log(`AI enriching ${channels.length} channels in ${batches.length} batches...`);
      await Promise.allSettled(batches.map(b => enrichBatch(b, query, niche, region)));
    }

    // ── Sort by relevance ─────────────────────────────────────────────────
    channels.sort((a, b) => (b.relevanceScore || 0) - (a.relevanceScore || 0));

    console.log(`Returning ${channels.length} creators`);
    return res.status(200).json({ creators: channels, total: channels.length });

  } catch(err) {
    console.error('Handler error:', err);
    return res.status(500).json({ error:'Server error: ' + (err.message || 'Unknown') });
  }
};
