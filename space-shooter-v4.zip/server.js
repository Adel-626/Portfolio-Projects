const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const os = require('os');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

const W = 900, H = 600;
const COLORS = ['#00d4ff','#ff6b35','#7fff00','#ff3cac','#ffd700','#a855f7','#ff4757','#2ed573'];
const MAX_ASTEROIDS = 18;

let asteroidId = 0;
let bulletId = 0;
let colorIndex = 0;

let state = { players: {}, asteroids: [], bullets: [] };
let explosions = [];

function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) return iface.address;
    }
  }
  return 'localhost';
}

function spawnAsteroid() {
  const side = Math.floor(Math.random() * 4);
  let x, y;
  if (side === 0) { x = Math.random() * W; y = -50; }
  else if (side === 1) { x = W + 50; y = Math.random() * H; }
  else if (side === 2) { x = Math.random() * W; y = H + 50; }
  else { x = -50; y = Math.random() * H; }

  const cx = W / 2 + (Math.random() - 0.5) * 300;
  const cy = H / 2 + (Math.random() - 0.5) * 200;
  const angle = Math.atan2(cy - y, cx - x) + (Math.random() - 0.5) * 1.2;
  const speed = 0.8 + Math.random() * 1.8;
  const size = 18 + Math.random() * 28;
  const numPoints = 7 + Math.floor(Math.random() * 4);
  const verts = [];
  for (let i = 0; i < numPoints; i++) {
    const a = (i / numPoints) * Math.PI * 2;
    const r = size * (0.65 + Math.random() * 0.35);
    verts.push([Math.cos(a) * r, Math.sin(a) * r]);
  }

  state.asteroids.push({
    id: asteroidId++,
    x, y,
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    size,
    rotation: Math.random() * Math.PI * 2,
    rotSpeed: (Math.random() - 0.5) * 0.04,
    verts
  });
}

setInterval(() => {
  state.asteroids.forEach(a => {
    a.x += a.vx;
    a.y += a.vy;
    a.rotation += a.rotSpeed;
  });

  state.bullets.forEach(b => {
    b.x += b.vx;
    b.y += b.vy;
    b.life--;
  });

  Object.values(state.players).forEach(p => {
    if (p.shield > 0) p.shield--;
  });

  state.asteroids = state.asteroids.filter(a =>
    a.x > -120 && a.x < W + 120 && a.y > -120 && a.y < H + 120
  );
  state.bullets = state.bullets.filter(b => b.life > 0);

  io.emit('state', { players: state.players, asteroids: state.asteroids, bullets: state.bullets });
}, 33);

setInterval(() => {
  const playerCount = Object.keys(state.players).length;
  if (playerCount > 0 && state.asteroids.length < MAX_ASTEROIDS) {
    const toSpawn = Math.min(2, MAX_ASTEROIDS - state.asteroids.length);
    for (let i = 0; i < toSpawn; i++) spawnAsteroid();
  }
}, 1800);

io.on('connection', (socket) => {
  console.log('Player connected:', socket.id);

  socket.on('join', (name) => {
    const color = COLORS[colorIndex % COLORS.length];
    colorIndex++;
    state.players[socket.id] = {
      id: socket.id,
      name: String(name).slice(0, 14) || 'Player',
      x: 100 + Math.random() * (W - 200),
      y: 100 + Math.random() * (H - 200),
      angle: -Math.PI / 2,
      vx: 0, vy: 0,
      score: 0,
      lives: 3,
      color,
      shield: 120,
      alive: true
    };
    io.emit('chat', { name: 'System', msg: `${state.players[socket.id].name} joined the game!`, color: '#aaa' });
  });

  socket.on('move', (data) => {
    const p = state.players[socket.id];
    if (!p) return;
    p.x = data.x;
    p.y = data.y;
    p.angle = data.angle;
    p.vx = data.vx;
    p.vy = data.vy;
  });

  socket.on('shoot', (data) => {
    const p = state.players[socket.id];
    if (!p) return;
    state.bullets.push({
      id: bulletId++,
      pid: socket.id,
      x: data.x,
      y: data.y,
      vx: data.vx,
      vy: data.vy,
      life: 55,
      color: p.color
    });
  });

  socket.on('destroyAsteroid', ({ aid, x, y }) => {
    const idx = state.asteroids.findIndex(a => a.id === aid);
    if (idx === -1) return;
    state.asteroids.splice(idx, 1);
    const p = state.players[socket.id];
    if (p) {
      p.score += 10;
      io.emit('explosion', { x, y, color: p.color });
    }
    if (state.asteroids.length < 5) {
      for (let i = 0; i < 3; i++) spawnAsteroid();
    }
  });

  socket.on('playerHit', ({ aid, x, y }) => {
    const p = state.players[socket.id];
    if (!p || p.shield > 0) return;
    const idx = state.asteroids.findIndex(a => a.id === aid);
    if (idx !== -1) state.asteroids.splice(idx, 1);
    p.lives--;
    p.shield = 150;
    io.emit('explosion', { x, y, color: '#ff4444' });
    if (p.lives <= 0) {
      p.lives = 0;
      p.alive = false;
      io.emit('chat', { name: 'System', msg: `${p.name} was destroyed!`, color: '#ff4757' });
      setTimeout(() => {
        if (state.players[socket.id]) {
          state.players[socket.id].lives = 3;
          state.players[socket.id].alive = true;
          state.players[socket.id].x = 100 + Math.random() * (W - 200);
          state.players[socket.id].y = 100 + Math.random() * (H - 200);
          state.players[socket.id].vx = 0;
          state.players[socket.id].vy = 0;
          state.players[socket.id].shield = 180;
          io.emit('chat', { name: 'System', msg: `${state.players[socket.id].name} respawned!`, color: '#7fff00' });
        }
      }, 3000);
    }
  });

  socket.on('chat', (msg) => {
    const p = state.players[socket.id];
    if (!p) return;
    io.emit('chat', { name: p.name, msg: String(msg).slice(0, 80), color: p.color });
  });

  socket.on('disconnect', () => {
    const p = state.players[socket.id];
    if (p) io.emit('chat', { name: 'System', msg: `${p.name} left the game.`, color: '#aaa' });
    delete state.players[socket.id];
    console.log('Player disconnected:', socket.id);
  });
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIP();
  console.log('\n🚀 Space Shooter is LIVE!\n');
  console.log(`  Open on THIS computer:  http://localhost:${PORT}`);
  console.log(`  Share with your network: http://${ip}:${PORT}`);
  console.log('\n  Share the network link with friends on the same WiFi!');
  console.log('  For internet access, use: npx ngrok http 3000\n');
});
